let handler = async m => m.reply(`
╭─「 Donasi • Pulsa 」
│ • Tree [0887889627310]
│ • Telkomsel [085271145771]
│ • Gopay [0887889627310]
╰────
╭─「 Hubungi 」
│ > Ingin donasi? Wa.me/62895704959080
╰────
`.trim()) // Tambah sendiri kalo mau
handler.help = ['donasi']
handler.tags = ['info']
handler.command = /^dona(te|si)$/i

module.exports = handler
