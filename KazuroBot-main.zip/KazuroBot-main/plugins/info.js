let handler  = async (m, { conn, usedPrefix: _p }) => {
  conn.reply(m.chat, `
╠═〘 INFO BOT 〙 ═
╠➥ Dibuat dengan bahasa javascript via NodeJs
╠➥ Rec: Aidil Tipi
╠➥ Script: @Nurotomo
║
╠➥ Github: https://github.com/Tipibot01/KazuroBot
╠➥ Instagram: @aidil.tipi
╠➥ YouTube: Aidil Tipi
║
╠═〘 Thanks To 〙 ═
╠➥ Allah.swt
╠➥ Nurotomo
╠➥ MfarelS
╠➥ ST4RZ
╠➥ Dan kawan yang lain :)
║
╠═〘 DONASI 〙 ═
╠➥ Tree: 0878-8962-7310
╠➥ Tsel: 0852-7114-5771
╠➥ Gopay: 0878-8962-7310
║
║>Request? Wa.me/62895704959080.
║
╠═〘 NfQ BOT 〙 ═
`.trim(), m)
}
handler.help = ['info']
handler.tags = ['info']
handler.command = /^(info)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler

